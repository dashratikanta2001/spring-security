package com.ovms.util;

public class AppConstants {

	
}
