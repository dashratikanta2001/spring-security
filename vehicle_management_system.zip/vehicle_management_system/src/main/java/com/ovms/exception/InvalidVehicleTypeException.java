package com.ovms.exception;

public class InvalidVehicleTypeException extends RuntimeException{

	public InvalidVehicleTypeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidVehicleTypeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
