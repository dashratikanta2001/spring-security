package com.ovms.enums;

public enum VehicleType {

	CAR, BIKE, SCOTTY;
	
}
