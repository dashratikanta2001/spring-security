package com.ovms.exception;

public class CustomUnauthorizeException extends RuntimeException{

	public CustomUnauthorizeException() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public CustomUnauthorizeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
